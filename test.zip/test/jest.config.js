module.exports = {
  testEnvironment: 'node',
  
  testMatch: [
    '**/tests/**/*.test.js',
    '**/tests/**/*.spec.js'
  ],
  
  testPathIgnorePatterns: [
    '/node_modules/',
    '/dist/',
    '/build/',
    '/coverage/',
    '/test/tests/',
    '/test/src/'
  ],
  
  setupFilesAfterEnv: [
    '<rootDir>/tests/utils/setup.js'
  ],
  
  collectCoverage: true,
  collectCoverageFrom: [
    'src/**/*.js',
    '!src/server.js',
    '!src/app.js',
    '!src/config/**',
    '!src/workers/**',
    '!**/node_modules/**',
    '!src/config/db.js'
  ],
  coverageDirectory: 'coverage',
  coverageReporters: ['text', 'text-summary', 'lcov', 'html', 'json'],
  coverageThreshold: {
    global: {
      branches: 50,
      functions: 50,
      lines: 50,
      statements: 50
    }
  },
  
  testTimeout: 60000,
  
  verbose: true,
  
  detectOpenHandles: true,
  forceExit: true,
  
  clearMocks: true,
  resetMocks: true,
  restoreMocks: true,
  
  moduleNameMapper: {
    '^@config$': '<rootDir>/src/config',
    '^@modules/(.*)$': '<rootDir>/src/modules/$1',
    '^@middlewares/(.*)$': '<rootDir>/src/middlewares/$1',
    '^@utils/(.*)$': '<rootDir>/src/utils/$1',
    '^@sockets/(.*)$': '<rootDir>/src/sockets/$1'
  },
  
  transform: {},
  
  reporters: ['default'],
  
  testEnvironmentOptions: {
    NODE_ENV: 'test'
  },
  
  maxWorkers: 2,
  
  errorOnDeprecated: true
};