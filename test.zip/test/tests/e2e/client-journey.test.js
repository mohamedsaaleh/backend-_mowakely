const request = require('supertest');
const app = require('../../src/app');
const { TestAuthHelper, TestUserFixture, TestCaseFixture, TestOfferFixture, DatabaseFixtures } = require('../utils/helpers');

describe('Client E2E Journey Tests', () => {
  let accessToken, refreshToken, userId;
  const userData = TestUserFixture.createClientData();

  beforeEach(async () => {
    await DatabaseFixtures.createCategories();

    const registerResponse = await request(app)
      .post('/api/auth/register')
      .send(userData);

    userId = registerResponse.body.data.user._id;
    accessToken = registerResponse.body.data.tokens.accessToken;
    refreshToken = registerResponse.body.data.tokens.refreshToken;
  });

  describe('Complete Client Workflow', () => {
    it('Register -> Login -> Get Profile -> Create Case -> Browse Cases -> Get My Cases', async () => {
      const loginResponse = await request(app)
        .post('/api/auth/login')
        .send({ email: userData.email, password: userData.password });

      expect(loginResponse.status).toBe(200);
      accessToken = loginResponse.body.data.tokens.accessToken;

      const profileResponse = await request(app)
        .get('/api/auth/me')
        .set('Authorization', `Bearer ${accessToken}`);

      expect(profileResponse.status).toBe(200);
      expect(profileResponse.body.data.email).toBe(userData.email);

      const caseData = TestCaseFixture.createCase();
      const createCaseResponse = await request(app)
        .post('/api/cases')
        .set('Authorization', `Bearer ${accessToken}`)
        .send(caseData);

      expect(createCaseResponse.status).toBe(201);
      const caseId = createCaseResponse.body.data._id;

      const browseCasesResponse = await request(app).get('/api/cases');
      expect(browseCasesResponse.status).toBe(200);

      const myCasesResponse = await request(app)
        .get('/api/cases/client/my-cases')
        .set('Authorization', `Bearer ${accessToken}`);

      expect(myCasesResponse.status).toBe(200);
      expect(myCasesResponse.body.data.items.length).toBe(1);
      expect(myCasesResponse.body.data.items[0]._id).toBe(caseId);
    });

    it('Create Case -> View Case -> Update Case -> Close Case', async () => {
      const caseData = TestCaseFixture.createCase({ status: 'open' });
      const createResponse = await request(app)
        .post('/api/cases')
        .set('Authorization', `Bearer ${accessToken}`)
        .send(caseData);

      const caseId = createResponse.body.data._id;

      const viewResponse = await request(app).get(`/api/cases/${caseId}`);
      expect(viewResponse.status).toBe(200);
      expect(viewResponse.body.data.title).toBe(caseData.title);

      const updateResponse = await request(app)
        .put(`/api/cases/${caseId}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .send({ description: 'Updated description for the case' });

      expect(updateResponse.status).toBe(200);
      expect(updateResponse.body.data.description).toBe('Updated description for the case');

      const closeResponse = await request(app)
        .put(`/api/cases/${caseId}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .send({ status: 'closed' });

      expect(closeResponse.status).toBe(200);
      expect(closeResponse.body.data.status).toBe('closed');
    });

    it('Create Case -> Receive Offers -> Accept One -> Reject Others', async () => {
      const caseData = TestCaseFixture.createCase();
      const createCaseResponse = await request(app)
        .post('/api/cases')
        .set('Authorization', `Bearer ${accessToken}`)
        .send(caseData);

      const caseId = createCaseResponse.body.data._id;

      const lawyer1 = await DatabaseFixtures.createLawyer();
      const lawyer1Token = TestAuthHelper.generateAccessToken(lawyer1.user._id, 'lawyer');
      const lawyer2 = await DatabaseFixtures.createLawyer();
      const lawyer2Token = TestAuthHelper.generateAccessToken(lawyer2.user._id, 'lawyer');

      await request(app)
        .post('/api/offers')
        .set('Authorization', `Bearer ${lawyer1Token}`)
        .send({ caseId, ...TestOfferFixture.createPendingOffer({ price: 5000 }) });

      await request(app)
        .post('/api/offers')
        .set('Authorization', `Bearer ${lawyer2Token}`)
        .send({ caseId, ...TestOfferFixture.createPendingOffer({ price: 4500 }) });

      const offersResponse = await request(app)
        .get(`/api/offers/case/${caseId}`)
        .set('Authorization', `Bearer ${accessToken}`);

      expect(offersResponse.body.data.length).toBe(2);

      const sortedOffers = offersResponse.body.data.sort((a, b) => a.price - b.price);
      const lowestOffer = sortedOffers[0];

      const acceptResponse = await request(app)
        .post(`/api/offers/${lowestOffer._id}/accept`)
        .set('Authorization', `Bearer ${accessToken}`);

      expect(acceptResponse.status).toBe(200);
      expect(acceptResponse.body.data.status).toBe('accepted');

      const caseResponse = await request(app).get(`/api/cases/${caseId}`);
      expect(caseResponse.body.data.status).toBe('in_progress');
      expect(caseResponse.body.data.lawyer).toBeDefined();
    });

    it('Refresh Token Flow', async () => {
      const refreshResponse = await request(app)
        .post('/api/auth/refresh')
        .send({ refreshToken });

      expect(refreshResponse.status).toBe(200);
      expect(refreshResponse.body.data.tokens.accessToken).toBeDefined();
    });

    it('Forgot Password Flow', async () => {
      const forgotResponse = await request(app)
        .post('/api/auth/forgot-password')
        .send({ email: userData.email });

      expect(forgotResponse.status).toBe(200);
    });

    it('Logout Flow', async () => {
      const logoutResponse = await request(app)
        .post('/api/auth/logout')
        .set('Authorization', `Bearer ${accessToken}`);

      expect(logoutResponse.status).toBe(200);
    });
  });

  describe('Client Case Management', () => {
    it('Create Multiple Cases -> Filter -> Search -> Delete', async () => {
      await request(app)
        .post('/api/cases')
        .set('Authorization', `Bearer ${accessToken}`)
        .send(TestCaseFixture.createCase({ title: 'Family Law Case', category: 'FAMILY LAW', status: 'open' }));

      await request(app)
        .post('/api/cases')
        .set('Authorization', `Bearer ${accessToken}`)
        .send(TestCaseFixture.createCase({ title: 'Criminal Defense', category: 'CRIMINAL DEFENSE', status: 'open' }));

      const myCasesResponse = await request(app)
        .get('/api/cases/client/my-cases')
        .set('Authorization', `Bearer ${accessToken}`);

      expect(myCasesResponse.body.data.items.length).toBe(2);

      const filterResponse = await request(app)
        .get('/api/cases?status=open')
        .set('Authorization', `Bearer ${accessToken}`);

      expect(filterResponse.status).toBe(200);

      const searchResponse = await request(app)
        .get('/api/cases?search=Family')
        .set('Authorization', `Bearer ${accessToken}`);

      expect(searchResponse.status).toBe(200);

      const allCasesResponse = await request(app)
        .get('/api/cases/client/my-cases')
        .set('Authorization', `Bearer ${accessToken}`);

      const caseId = allCasesResponse.body.data.items[0]._id;

      const deleteResponse = await request(app)
        .delete(`/api/cases/${caseId}`)
        .set('Authorization', `Bearer ${accessToken}`);

      expect(deleteResponse.status).toBe(200);
    });
  });
});