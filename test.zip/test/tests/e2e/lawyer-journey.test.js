const request = require('supertest');
const app = require('../../src/app');
const { TestAuthHelper, TestUserFixture, TestCaseFixture, TestOfferFixture, DatabaseFixtures } = require('../utils/helpers');

describe('Lawyer E2E Journey Tests', () => {
  let accessToken, userId;
  const userData = TestUserFixture.createLawyerData();

  beforeEach(async () => {
    await DatabaseFixtures.createCategories();

    const registerResponse = await request(app)
      .post('/api/auth/register')
      .send(userData);

    userId = registerResponse.body.data.user._id;
    accessToken = registerResponse.body.data.tokens.accessToken;
  });

  describe('Complete Lawyer Workflow', () => {
    it('Register -> Login -> Update Profile -> Browse Cases -> Make Offer', async () => {
      const loginResponse = await request(app)
        .post('/api/auth/login')
        .send({ email: userData.email, password: userData.password });

      expect(loginResponse.status).toBe(200);
      accessToken = loginResponse.body.data.tokens.accessToken;

      const profileResponse = await request(app)
        .get('/api/auth/me')
        .set('Authorization', `Bearer ${accessToken}`);

      expect(profileResponse.body.data.role).toBe('lawyer');

      const browseResponse = await request(app).get('/api/cases?status=open');
      expect(browseResponse.status).toBe(200);

      const client = await DatabaseFixtures.createClient();
      const caseData = await DatabaseFixtures.createCase({ status: 'open' }, { user: client.user });

      const offerData = TestOfferFixture.createPendingOffer({ price: 5000, timeline: 7 });
      const offerResponse = await request(app)
        .post('/api/offers')
        .set('Authorization', `Bearer ${accessToken}`)
        .send({ caseId: caseData.case._id.toString(), ...offerData });

      expect(offerResponse.status).toBe(201);
      expect(offerResponse.body.data.status).toBe('pending');
      expect(offerResponse.body.data.price).toBe(5000);
    });

    it('Browse Cases -> Search by Category -> Create Offer -> View My Offers', async () => {
      const client = await DatabaseFixtures.createClient();
      await DatabaseFixtures.createCase({ category: 'FAMILY LAW', status: 'open' }, { user: client.user });

      const categoryResponse = await request(app).get('/api/cases?category=FAMILY LAW');
      expect(categoryResponse.status).toBe(200);

      const caseData = await DatabaseFixtures.createCase({ category: 'FAMILY LAW', status: 'open' }, { user: client.user });

      const offerResponse = await request(app)
        .post('/api/offers')
        .set('Authorization', `Bearer ${accessToken}`)
        .send({ caseId: caseData.case._id.toString(), ...TestOfferFixture.createPendingOffer() });

      expect(offerResponse.status).toBe(201);

      const myOffersResponse = await request(app)
        .get('/api/offers')
        .set('Authorization', `Bearer ${accessToken}`);

      expect(myOffersResponse.status).toBe(200);
      expect(myOffersResponse.body.data.items.length).toBeGreaterThan(0);
    });

    it('Create Offer -> Update Offer -> Withdraw Offer', async () => {
      const client = await DatabaseFixtures.createClient();
      const caseData = await DatabaseFixtures.createCase({ status: 'open' }, { user: client.user });

      const createOfferResponse = await request(app)
        .post('/api/offers')
        .set('Authorization', `Bearer ${accessToken}`)
        .send({ caseId: caseData.case._id.toString(), ...TestOfferFixture.createPendingOffer() });

      const offerId = createOfferResponse.body.data._id;

      const updateResponse = await request(app)
        .put(`/api/offers/${offerId}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .send({ price: 4500, description: 'Updated offer details' });

      expect(updateResponse.status).toBe(200);
      expect(updateResponse.body.data.price).toBe(4500);

      const withdrawResponse = await request(app)
        .delete(`/api/offers/${offerId}`)
        .set('Authorization', `Bearer ${accessToken}`);

      expect(withdrawResponse.status).toBe(200);
    });

    it('View Assigned Cases -> Update Case Status', async () => {
      const client = await DatabaseFixtures.createClient();
      const clientToken = TestAuthHelper.generateAccessToken(client.user._id, 'client');

      const caseData = await DatabaseFixtures.createCase({ status: 'open' }, { user: client.user });

      const offerData = TestOfferFixture.createPendingOffer();
      const offerResponse = await request(app)
        .post('/api/offers')
        .set('Authorization', `Bearer ${accessToken}`)
        .send({ caseId: caseData.case._id.toString(), ...offerData });

      await request(app)
        .post(`/api/offers/${offerResponse.body.data._id}/accept`)
        .set('Authorization', `Bearer ${clientToken}`);

      const assignedResponse = await request(app)
        .get('/api/cases/lawyer/assigned')
        .set('Authorization', `Bearer ${accessToken}`);

      expect(assignedResponse.status).toBe(200);
      expect(assignedResponse.body.data.items.length).toBe(1);

      const caseId = assignedResponse.body.data.items[0]._id;
      const updateCaseResponse = await request(app)
        .put(`/api/cases/${caseId}`)
        .set('Authorization', `Bearer ${accessToken}`)
        .send({ status: 'completed' });

      expect(updateCaseResponse.status).toBe(200);
      expect(updateCaseResponse.body.data.status).toBe('completed');
    });
  });

  describe('Lawyer Profile & Specialization', () => {
    it('Should have lawyer-specific endpoints', async () => {
      const lawyerProfileResponse = await request(app)
        .get('/api/lawyers/profile')
        .set('Authorization', `Bearer ${accessToken}`);

      expect(lawyerProfileResponse.status).toBe(200);

      const statsResponse = await request(app)
        .get('/api/lawyers/stats')
        .set('Authorization', `Bearer ${accessToken}`);

      expect(statsResponse.status).toBe(200);
    });

    it('Should track offered cases', async () => {
      const client = await DatabaseFixtures.createClient();

      for (let i = 0; i < 3; i++) {
        const caseData = await DatabaseFixtures.createCase({ status: 'open' }, { user: client.user });
        await request(app)
          .post('/api/offers')
          .set('Authorization', `Bearer ${accessToken}`)
          .send({ caseId: caseData.case._id.toString(), ...TestOfferFixture.createPendingOffer() });
      }

      const myOffersResponse = await request(app)
        .get('/api/offers')
        .set('Authorization', `Bearer ${accessToken}`);

      expect(myOffersResponse.body.data.items.length).toBe(3);

      const pendingOffersResponse = await request(app)
        .get('/api/offers?status=pending')
        .set('Authorization', `Bearer ${accessToken}`);

      expect(pendingOffersResponse.status).toBe(200);
    });
  });
});