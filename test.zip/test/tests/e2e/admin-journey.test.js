const request = require('supertest');
const app = require('../../src/app');
const { TestAuthHelper, TestUserFixture, TestCategoryFixture, DatabaseFixtures } = require('../utils/helpers');

describe('Admin E2E Journey Tests', () => {
  let adminToken, adminId;
  const adminData = TestUserFixture.createAdminData();

  beforeEach(async () => {
    await DatabaseFixtures.createCategories();

    const registerResponse = await request(app)
      .post('/api/auth/register')
      .send(adminData);

    adminId = registerResponse.body.data.user._id;
    adminToken = registerResponse.body.data.tokens.accessToken;
  });

  describe('Complete Admin Workflow', () => {
    it('Register -> Login -> Get All Users -> Manage Categories', async () => {
      const loginResponse = await request(app)
        .post('/api/auth/login')
        .send({ email: adminData.email, password: adminData.password });

      expect(loginResponse.status).toBe(200);
      adminToken = loginResponse.body.data.tokens.accessToken;

      const profileResponse = await request(app)
        .get('/api/auth/me')
        .set('Authorization', `Bearer ${adminToken}`);

      expect(profileResponse.body.data.role).toBe('admin');

      const usersResponse = await request(app)
        .get('/api/admin/users')
        .set('Authorization', `Bearer ${adminToken}`);

      expect(usersResponse.status).toBe(200);
    });

    it('Create Category -> Update Category -> Delete Category', async () => {
      const categoryData = TestCategoryFixture.createCategory({ name: 'NEW CATEGORY' });

      const createResponse = await request(app)
        .post('/api/categories')
        .set('Authorization', `Bearer ${adminToken}`)
        .send(categoryData);

      expect(createResponse.status).toBe(201);
      const categoryId = createResponse.body.data._id;

      const updateResponse = await request(app)
        .put(`/api/categories/${categoryId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ name: 'UPDATED CATEGORY', description: 'Updated description' });

      expect(updateResponse.status).toBe(200);
      expect(updateResponse.body.data.name).toBe('UPDATED CATEGORY');

      const deleteResponse = await request(app)
        .delete(`/api/categories/${categoryId}`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(deleteResponse.status).toBe(200);
    });
  });

  describe('Admin User Management', () => {
    it('Get All Users -> Filter by Role -> View User Details', async () => {
      await DatabaseFixtures.createClient();
      await DatabaseFixtures.createLawyer();

      const allUsersResponse = await request(app)
        .get('/api/admin/users')
        .set('Authorization', `Bearer ${adminToken}`);

      expect(allUsersResponse.status).toBe(200);
      expect(allUsersResponse.body.data.items.length).toBeGreaterThan(1);

      const clientsResponse = await request(app)
        .get('/api/admin/users?role=client')
        .set('Authorization', `Bearer ${adminToken}`);

      expect(clientsResponse.status).toBe(200);

      const lawyersResponse = await request(app)
        .get('/api/admin/users?role=lawyer')
        .set('Authorization', `Bearer ${adminToken}`);

      expect(lawyersResponse.status).toBe(200);
    });

    it('View User -> Update User -> Delete User', async () => {
      const client = await DatabaseFixtures.createClient();

      const viewResponse = await request(app)
        .get(`/api/admin/users/${client.user._id}`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(viewResponse.status).toBe(200);

      const updateResponse = await request(app)
        .put(`/api/admin/users/${client.user._id}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ isActive: false });

      expect(updateResponse.status).toBe(200);
      expect(updateResponse.body.data.isActive).toBe(false);
    });
  });

  describe('Admin Case Management', () => {
    it('View All Cases -> Filter Cases -> View Case Details', async () => {
      const client = await DatabaseFixtures.createClient();
      await DatabaseFixtures.createCase({}, { user: client.user });

      const allCasesResponse = await request(app)
        .get('/api/admin/cases')
        .set('Authorization', `Bearer ${adminToken}`);

      expect(allCasesResponse.status).toBe(200);

      const openCasesResponse = await request(app)
        .get('/api/admin/cases?status=open')
        .set('Authorization', `Bearer ${adminToken}`);

      expect(openCasesResponse.status).toBe(200);
    });

    it('Delete Any Case', async () => {
      const client = await DatabaseFixtures.createClient();
      const caseData = await DatabaseFixtures.createCase({}, { user: client.user });

      const deleteResponse = await request(app)
        .delete(`/api/cases/${caseData.case._id}`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(deleteResponse.status).toBe(200);

      const viewResponse = await request(app).get(`/api/cases/${caseData.case._id}`);
      expect(viewResponse.status).toBe(404);
    });
  });

  describe('Admin Dashboard', () => {
    it('Get Dashboard Statistics', async () => {
      const client = await DatabaseFixtures.createClient();
      const lawyer = await DatabaseFixtures.createLawyer();

      await DatabaseFixtures.createCase({}, { user: client.user });

      const dashboardResponse = await request(app)
        .get('/api/admin/dashboard')
        .set('Authorization', `Bearer ${adminToken}`);

      expect(dashboardResponse.status).toBe(200);
      expect(dashboardResponse.body.data).toHaveProperty('totalUsers');
      expect(dashboardResponse.body.data).toHaveProperty('totalCases');
    });
  });

  describe('Admin Categories Management', () => {
    it('Create Multiple Categories -> List Categories -> Search Category', async () => {
      await request(app)
        .post('/api/categories')
        .set('Authorization', `Bearer ${adminToken}`)
        .send(TestCategoryFixture.createCategory({ name: 'CATEGORY A' }));

      await request(app)
        .post('/api/categories')
        .set('Authorization', `Bearer ${adminToken}`)
        .send(TestCategoryFixture.createCategory({ name: 'CATEGORY B' }));

      const listResponse = await request(app).get('/api/categories');
      expect(listResponse.body.data.length).toBeGreaterThan(2);

      const searchResponse = await request(app)
        .get('/api/categories?search=FAMILY')
        .set('Authorization', `Bearer ${adminToken}`);

      expect(searchResponse.status).toBe(200);
    });
  });

  describe('Authorization Checks', () => {
    it('Should deny client access to admin endpoints', async () => {
      const client = await DatabaseFixtures.createClient();
      const clientToken = TestAuthHelper.generateAccessToken(client.user._id, 'client');

      const response = await request(app)
        .get('/api/admin/users')
        .set('Authorization', `Bearer ${clientToken}`);

      expect(response.status).toBe(403);
    });

    it('Should deny lawyer access to admin endpoints', async () => {
      const lawyer = await DatabaseFixtures.createLawyer();
      const lawyerToken = TestAuthHelper.generateAccessToken(lawyer.user._id, 'lawyer');

      const response = await request(app)
        .get('/api/admin/users')
        .set('Authorization', `Bearer ${lawyerToken}`);

      expect(response.status).toBe(403);
    });
  });
});