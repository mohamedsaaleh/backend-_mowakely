const request = require('supertest');
const app = require('../../src/app');
const { TestAuthHelper, TestCaseFixture, DatabaseFixtures } = require('../utils/helpers');

describe('Cases Integration Tests', () => {
  let clientToken, clientUser, lawyerToken, lawyerUser;

  beforeEach(async () => {
    // Create client and get token
    const client = await DatabaseFixtures.createClient();
    clientUser = client.user;
    clientToken = TestAuthHelper.generateAccessToken(clientUser._id, 'client');

    // Create lawyer and get token
    const lawyer = await DatabaseFixtures.createLawyer();
    lawyerUser = lawyer.user;
    lawyerToken = TestAuthHelper.generateAccessToken(lawyerUser._id, 'lawyer');

    // Create categories
    await DatabaseFixtures.createCategories();
  });

  describe('GET /api/cases', () => {
    const casesEndpoint = '/api/cases';

    it('should get all cases without auth', async () => {
      await DatabaseFixtures.createCase({}, { user: clientUser });

      const response = await request(app).get(casesEndpoint);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.items).toBeDefined();
    });

    it('should filter cases by status', async () => {
      const caseData = await DatabaseFixtures.createCase({ status: 'open' }, { user: clientUser });

      const response = await request(app)
        .get(`${casesEndpoint}?status=open`);

      expect(response.status).toBe(200);
      expect(response.body.data.items.length).toBeGreaterThan(0);
    });

    it('should filter cases by category', async () => {
      const category = await DatabaseFixtures.createCategory({ name: 'FAMILY LAW' });
      await DatabaseFixtures.createCase({
        category: 'FAMILY LAW',
        categoryId: category._id
      }, { user: clientUser });

      const response = await request(app)
        .get(`${casesEndpoint}?category=FAMILY LAW`);

      expect(response.status).toBe(200);
    });

    it('should filter cases by priority', async () => {
      await DatabaseFixtures.createCase({ priority: 'high' }, { user: clientUser });

      const response = await request(app)
        .get(`${casesEndpoint}?priority=high`);

      expect(response.status).toBe(200);
    });

    it('should support pagination', async () => {
      const response = await request(app)
        .get(`${casesEndpoint}?page=1&limit=10`);

      expect(response.status).toBe(200);
      expect(response.body.data.pagination).toHaveProperty('page');
      expect(response.body.data.pagination).toHaveProperty('limit');
      expect(response.body.data.pagination).toHaveProperty('total');
    });

    it('should support sorting', async () => {
      const response = await request(app)
        .get(`${casesEndpoint}?sort=-createdAt`);

      expect(response.status).toBe(200);
    });

    it('should support search', async () => {
      await DatabaseFixtures.createCase({ title: 'Specific Divorce Case' }, { user: clientUser });

      const response = await request(app)
        .get(`${casesEndpoint}?search=Divorce`);

      expect(response.status).toBe(200);
    });
  });

  describe('POST /api/cases', () => {
    const createCaseEndpoint = '/api/cases';

    it('should create case as client', async () => {
      const caseData = TestCaseFixture.createCase();

      const response = await request(app)
        .post(createCaseEndpoint)
        .set('Authorization', `Bearer ${clientToken}`)
        .send(caseData);

      expect(response.status).toBe(201);
      expect(response.body.success).toBe(true);
      expect(response.body.data.title).toBe(caseData.title);
    });

    it('should reject case creation without auth', async () => {
      const caseData = TestCaseFixture.createCase();

      const response = await request(app)
        .post(createCaseEndpoint)
        .send(caseData);

      expect(response.status).toBe(401);
    });

    it('should reject case creation as lawyer', async () => {
      const caseData = TestCaseFixture.createCase();

      const response = await request(app)
        .post(createCaseEndpoint)
        .set('Authorization', `Bearer ${lawyerToken}`)
        .send(caseData);

      expect(response.status).toBe(403);
    });

    it('should reject case without title', async () => {
      const caseData = TestCaseFixture.createCase();
      delete caseData.title;

      const response = await request(app)
        .post(createCaseEndpoint)
        .set('Authorization', `Bearer ${clientToken}`)
        .send(caseData);

      expect(response.status).toBe(400);
    });

    it('should reject case without description', async () => {
      const caseData = TestCaseFixture.createCase();
      delete caseData.description;

      const response = await request(app)
        .post(createCaseEndpoint)
        .set('Authorization', `Bearer ${clientToken}`)
        .send(caseData);

      expect(response.status).toBe(400);
    });

    it('should reject case without category', async () => {
      const caseData = TestCaseFixture.createCase();
      delete caseData.category;

      const response = await request(app)
        .post(createCaseEndpoint)
        .set('Authorization', `Bearer ${clientToken}`)
        .send(caseData);

      expect(response.status).toBe(400);
    });

    it('should reject case without budget', async () => {
      const caseData = TestCaseFixture.createCase();
      delete caseData.budget;

      const response = await request(app)
        .post(createCaseEndpoint)
        .send({ ...caseData, budget: undefined })
        .set('Authorization', `Bearer ${clientToken}`);

      expect(response.status).toBe(400);
    });

    it('should reject case with negative budget', async () => {
      const caseData = TestCaseFixture.createCase({ budget: -1000 });

      const response = await request(app)
        .post(createCaseEndpoint)
        .set('Authorization', `Bearer ${clientToken}`)
        .send(caseData);

      expect(response.status).toBe(400);
    });
  });

  describe('GET /api/cases/:id', () => {
    it('should get case by id without auth', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });

      const response = await request(app)
        .get(`/api/cases/${caseData.case._id}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
      expect(response.body.data.title).toBe(caseData.case.title);
    });

    it('should return 404 for non-existent case', async () => {
      const response = await request(app)
        .get('/api/cases/507f1f77bcf86cd799439011');

      expect(response.status).toBe(404);
    });

    it('should populate category details', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });

      const response = await request(app)
        .get(`/api/cases/${caseData.case._id}`);

      expect(response.status).toBe(200);
      expect(response.body.data.categoryId).toBeDefined();
    });
  });

  describe('PUT /api/cases/:id', () => {
    it('should update case as owner (client)', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });

      const response = await request(app)
        .put(`/api/cases/${caseData.case._id}`)
        .set('Authorization', `Bearer ${clientToken}`)
        .send({ title: 'Updated Title' });

      expect(response.status).toBe(200);
      expect(response.body.data.title).toBe('Updated Title');
    });

    it('should reject update as non-owner', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });
      const otherClient = await DatabaseFixtures.createClient();
      const otherToken = TestAuthHelper.generateAccessToken(otherClient.user._id, 'client');

      const response = await request(app)
        .put(`/api/cases/${caseData.case._id}`)
        .set('Authorization', `Bearer ${otherToken}`)
        .send({ title: 'Updated Title' });

      expect(response.status).toBe(403);
    });

    it('should allow lawyer to update assigned case', async () => {
      const caseData = await DatabaseFixtures.createCase({
        lawyer: lawyerUser._id,
        status: 'in_progress'
      }, { user: clientUser });

      const response = await request(app)
        .put(`/api/cases/${caseData.case._id}`)
        .set('Authorization', `Bearer ${lawyerToken}`)
        .send({ description: 'Updated description' });

      expect(response.status).toBe(200);
    });

    it('should reject update without auth', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });

      const response = await request(app)
        .put(`/api/cases/${caseData.case._id}`)
        .send({ title: 'Updated Title' });

      expect(response.status).toBe(401);
    });
  });

  describe('DELETE /api/cases/:id', () => {
    it('should delete case as owner', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });

      const response = await request(app)
        .delete(`/api/cases/${caseData.case._id}`)
        .set('Authorization', `Bearer ${clientToken}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
    });

    it('should reject delete as non-owner', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });
      const otherClient = await DatabaseFixtures.createClient();
      const otherToken = TestAuthHelper.generateAccessToken(otherClient.user._id, 'client');

      const response = await request(app)
        .delete(`/api/cases/${caseData.case._id}`)
        .set('Authorization', `Bearer ${otherToken}`);

      expect(response.status).toBe(403);
    });

    it('should allow admin to delete any case', async () => {
      const admin = await DatabaseFixtures.createAdmin();
      const adminToken = TestAuthHelper.generateAccessToken(admin._id, 'admin');
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });

      const response = await request(app)
        .delete(`/api/cases/${caseData.case._id}`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
    });
  });
});