const request = require('supertest');
const app = require('../../src/app');
const { TestAuthHelper, TestOfferFixture, DatabaseFixtures } = require('../utils/helpers');

describe('Offers Integration Tests', () => {
  let clientToken, clientUser, lawyerToken, lawyerUser;

  beforeEach(async () => {
    const client = await DatabaseFixtures.createClient();
    clientUser = client.user;
    clientToken = TestAuthHelper.generateAccessToken(clientUser._id, 'client');

    const lawyer = await DatabaseFixtures.createLawyer();
    lawyerUser = lawyer.user;
    lawyerToken = TestAuthHelper.generateAccessToken(lawyerUser._id, 'lawyer');
  });

  describe('POST /api/offers', () => {
    it('should create and return offer with case details', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });
      const offerData = TestOfferFixture.createPendingOffer();

      const response = await request(app)
        .post('/api/offers')
        .set('Authorization', `Bearer ${lawyerToken}`)
        .send({ caseId: caseData.case._id.toString(), ...offerData });

      expect(response.status).toBe(201);
      expect(response.body.data.caseId).toBeDefined();
      expect(response.body.data.lawyerId).toBeDefined();
    });

    it('should create offer with valid timeline', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });
      const offerData = TestOfferFixture.createPendingOffer({ timeline: 7 });

      const response = await request(app)
        .post('/api/offers')
        .set('Authorization', `Bearer ${lawyerToken}`)
        .send({ caseId: caseData.case._id.toString(), ...offerData });

      expect(response.status).toBe(201);
      expect(response.body.data.timeline).toBe(7);
    });

    it('should reject duplicate offer from same lawyer', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });
      const offerData = TestOfferFixture.createPendingOffer();

      await request(app)
        .post('/api/offers')
        .set('Authorization', `Bearer ${lawyerToken}`)
        .send({ caseId: caseData.case._id.toString(), ...offerData });

      const response = await request(app)
        .post('/api/offers')
        .set('Authorization', `Bearer ${lawyerToken}`)
        .send({ caseId: caseData.case._id.toString(), ...offerData });

      expect(response.status).toBe(400);
    });
  });

  describe('GET /api/offers', () => {
    it('should get lawyer own offers', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });
      await DatabaseFixtures.createOffer({}, { user: lawyerUser }, caseData.case);

      const response = await request(app)
        .get('/api/offers')
        .set('Authorization', `Bearer ${lawyerToken}`);

      expect(response.status).toBe(200);
      expect(response.body.data.items.length).toBeGreaterThan(0);
    });

    it('should filter offers by status', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });
      await DatabaseFixtures.createOffer({ status: 'pending' }, { user: lawyerUser }, caseData.case);

      const response = await request(app)
        .get('/api/offers?status=pending')
        .set('Authorization', `Bearer ${lawyerToken}`);

      expect(response.status).toBe(200);
    });
  });

  describe('Accept/Reject Flow', () => {
    it('should auto-reject other offers when one is accepted', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });
      const otherLawyer = await DatabaseFixtures.createLawyer();

      const offer1 = await DatabaseFixtures.createOffer({}, { user: lawyerUser }, caseData.case);
      await DatabaseFixtures.createOffer({}, { user: otherLawyer.user }, caseData.case);

      await request(app)
        .post(`/api/offers/${offer1.offer._id}/accept`)
        .set('Authorization', `Bearer ${clientToken}`);

      const response = await request(app)
        .get(`/api/offers/case/${caseData.case._id}`)
        .set('Authorization', `Bearer ${clientToken}`);

      const acceptedOffer = response.body.data.find(o => o.status === 'accepted');
      const rejectedOffers = response.body.data.filter(o => o.status === 'rejected');

      expect(acceptedOffer).toBeDefined();
      expect(rejectedOffers.length).toBeGreaterThan(0);
    });

    it('should update case status when offer accepted', async () => {
      const caseData = await DatabaseFixtures.createCase({ status: 'open' }, { user: clientUser });
      const offerData = await DatabaseFixtures.createOffer({}, { user: lawyerUser }, caseData.case);

      await request(app)
        .post(`/api/offers/${offerData.offer._id}/accept`)
        .set('Authorization', `Bearer ${clientToken}`);

      const caseResponse = await request(app).get(`/api/cases/${caseData.case._id}`);

      expect(caseResponse.body.data.status).toBe('in_progress');
      expect(caseResponse.body.data.lawyer).toBeDefined();
    });
  });
});