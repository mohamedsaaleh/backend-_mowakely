// const { Socket } = require('socket.io-client');
// const { io } = require('socket.io-client');
// const app = require('../../src/app');
// const { TestAuthHelper, DatabaseFixtures } = require('../utils/helpers');

// const SOCKET_URL = process.env.SOCKET_URL || 'http://localhost:3000';

// describe('Socket.IO Chat Tests', () => {
//   let clientSocket, lawyerSocket, clientToken, lawyerToken, clientId, lawyerId;

//   beforeAll(async () => {
//     await new Promise(resolve => setTimeout(resolve, 1000));
//   });

//   beforeEach(async () => {
//     const client = await DatabaseFixtures.createClient();
//     clientId = client.user._id;
//     clientToken = TestAuthHelper.generateAccessToken(clientId, 'client');

//     const lawyer = await DatabaseFixtures.createLawyer();
//     lawyerId = lawyer.user._id;
//     lawyerToken = TestAuthHelper.generateAccessToken(lawyerId, 'lawyer');
//   });

//   afterEach(() => {
//     if (clientSocket) clientSocket.disconnect();
//     if (lawyerSocket) lawyerSocket.disconnect();
//   });

//   describe('Socket Connection', () => {
//     it('should connect with valid token', (done) => {
//       clientSocket = io(SOCKET_URL, {
//         auth: { token: clientToken },
//         transports: ['websocket'],
//         forceNew: true
//       });

//       clientSocket.on('connect', () => {
//         expect(clientSocket.connected).toBe(true);
//         done();
//       });

//       clientSocket.on('connect_error', (err) => {
//         done(err);
//       });
//     });

//     it('should reject connection without token', (done) => {
//       const socket = io(SOCKET_URL, {
//         transports: ['websocket'],
//         forceNew: true
//       });

//       socket.on('connect', () => {
//         socket.disconnect();
//         done(new Error('Should not connect without token'));
//       });

//       socket.on('connect_error', (err) => {
//         expect(err.message).toContain('Authentication');
//         done();
//       });
//     });

//     it('should reject connection with invalid token', (done) => {
//       const socket = io(SOCKET_URL, {
//         auth: { token: 'invalid-token' },
//         transports: ['websocket'],
//         forceNew: true
//       });

//       socket.on('connect', () => {
//         socket.disconnect();
//         done(new Error('Should not connect with invalid token'));
//       });

//       socket.on('connect_error', (err) => {
//         expect(err.message).toContain('Authentication');
//         done();
//       });
//     });
//   });

//   describe('Join/Leave Rooms', () => {
//     it('should join case room', (done) => {
//       clientSocket = io(SOCKET_URL, {
//         auth: { token: clientToken },
//         transports: ['websocket'],
//         forceNew: true
//       });

//       clientSocket.on('connect', () => {
//         clientSocket.emit('join:case', { caseId: '507f1f77bcf86cd799439011' });

//         clientSocket.on('joined:case', (data) => {
//           expect(data.caseId).toBeDefined();
//           done();
//         });

//         setTimeout(() => done(), 1000);
//       });
//     });

//     it('should leave case room', (done) => {
//       clientSocket = io(SOCKET_URL, {
//         auth: { token: clientToken },
//         transports: ['websocket'],
//         forceNew: true
//       });

//       clientSocket.on('connect', () => {
//         clientSocket.emit('leave:case', { caseId: '507f1f77bcf86cd799439011' });

//         clientSocket.on('left:case', (data) => {
//           expect(data.caseId).toBeDefined();
//           done();
//         });

//         setTimeout(() => done(), 1000);
//       });
//     });
//   });

//   describe('Messaging', () => {
//     it('should send and receive message', (done) => {
//       clientSocket = io(SOCKET_URL, {
//         auth: { token: clientToken },
//         transports: ['websocket'],
//         forceNew: true
//       });

//       lawyerSocket = io(SOCKET_URL, {
//         auth: { token: lawyerToken },
//         transports: ['websocket'],
//         forceNew: true
//       });

//       let connectedClients = 0;

//       const onConnect = () => {
//         connectedClients++;
//         if (connectedClients === 2) {
//           const caseId = '507f1f77bcf86cd799439011';

//           lawyerSocket.emit('join:case', { caseId });
//           clientSocket.emit('join:case', { caseId });

//           setTimeout(() => {
//             clientSocket.emit('message:send', {
//               caseId,
//               content: 'Hello from client'
//             });
//           }, 500);
//         }
//       };

//       clientSocket.on('connect', onConnect);
//       lawyerSocket.on('connect', onConnect);

//       lawyerSocket.on('message:received', (data) => {
//         expect(data.content).toBe('Hello from client');
//         expect(data.senderId).toBe(clientId.toString());
//         done();
//       });

//       setTimeout(() => done(new Error('Timeout waiting for message')), 3000);
//     });

//     it('should receive typing indicator', (done) => {
//       clientSocket = io(SOCKET_URL, {
//         auth: { token: clientToken },
//         transports: ['websocket'],
//         forceNew: true
//       });

//       lawyerSocket = io(SOCKET_URL, {
//         auth: { token: lawyerToken },
//         transports: ['websocket'],
//         forceNew: true
//       });

//       let connectedClients = 0;

//       const onConnect = () => {
//         connectedClients++;
//         if (connectedClients === 2) {
//           const caseId = '507f1f77bcf86cd799439011';

//           lawyerSocket.emit('join:case', { caseId });
//           clientSocket.emit('join:case', { caseId });

//           setTimeout(() => {
//             clientSocket.emit('typing:start', { caseId });
//           }, 500);
//         }
//       };

//       clientSocket.on('connect', onConnect);
//       lawyerSocket.on('connect', onConnect);

//       lawyerSocket.on('typing:indicator', (data) => {
//         expect(data.userId).toBe(clientId.toString());
//         expect(data.isTyping).toBe(true);
//         done();
//       });

//       setTimeout(() => done(new Error('Timeout waiting for typing')), 3000);
//     });
//   });

//   describe('Notifications', () => {
//     it('should receive notification on new offer', (done) => {
//       clientSocket = io(SOCKET_URL, {
//         auth: { token: clientToken },
//         transports: ['websocket'],
//         forceNew: true
//       });

//       clientSocket.on('connect', () => {
//         clientSocket.on('notification', (data) => {
//           expect(data.type).toBe('new_offer');
//           done();
//         });

//         setTimeout(() => done(new Error('Timeout waiting for notification')), 3000);
//       });
//     });
//   });

//   describe('Disconnection', () => {
//     it('should handle disconnect gracefully', (done) => {
//       clientSocket = io(SOCKET_URL, {
//         auth: { token: clientToken },
//         transports: ['websocket'],
//         forceNew: true
//       });

//       clientSocket.on('connect', () => {
//         clientSocket.disconnect();

//         clientSocket.on('disconnect', (reason) => {
//           expect(reason).toBeDefined();
//           done();
//         });
//       });
//     });
//   });
// });