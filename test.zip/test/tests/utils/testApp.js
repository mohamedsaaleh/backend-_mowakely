const request = require('supertest');
const app = require('../../src/app');
const { mongoose } = require('./setup');

class TestApp {
  constructor() {
    this.app = app;
    this.agent = request.agent(app);
  }

  /**
   * Make GET request
   */
  async get(path, options = {}) {
    return this.agent
      .get(path)
      .set(options.headers || {})
      .send();
  }

  /**
   * Make POST request
   */
  async post(path, data, options = {}) {
    return this.agent
      .post(path)
      .set(options.headers || {})
      .send(data);
  }

  /**
   * Make PUT request
   */
  async put(path, data, options = {}) {
    return this.agent
      .put(path)
      .set(options.headers || {})
      .send(data);
  }

  /**
   * Make PATCH request
   */
  async patch(path, data, options = {}) {
    return this.agent
      .patch(path)
      .set(options.headers || {})
      .send(data);
  }

  /**
   * Make DELETE request
   */
  async delete(path, options = {}) {
    return this.agent
      .delete(path)
      .set(options.headers || {})
      .send();
  }

  /**
   * Make request with file upload
   */
  async upload(path, fieldName, file, options = {}) {
    return this.agent
      .post(path)
      .set(options.headers || {})
      .attach(fieldName, file);
  }

  /**
   * Set authentication header
   */
  withAuth(token) {
    return {
      headers: {
        Authorization: `Bearer ${token}`
      }
    };
  }

  /**
   * Set role
   */
  withRole(role) {
    return this;
  }

  /**
   * Get health status
   */
  async healthCheck() {
    return this.get('/api/health');
  }

  /**
   * Get detailed health
   */
  async detailedHealthCheck() {
    return this.get('/api/health/detailed');
  }
}

function createTestApp() {
  return new TestApp();
}

/**
 * Direct supertest wrapper
 */
async function makeRequest(appInstance, method, path, data = null, headers = {}) {
  let req = request(appInstance)[method](path).set(headers);
  
  if (data) {
    req = req.send(data);
  }
  
  return req;
}

/**
 * Create authenticated request
 */
async function makeAuthenticatedRequest(appInstance, method, path, token, data = null) {
  return makeRequest(
    appInstance,
    method,
    path,
    data,
    { Authorization: `Bearer ${token}` }
  );
}

/**
 * Create admin request
 */
async function makeAdminRequest(appInstance, method, path, token, data = null) {
  return makeAuthenticatedRequest(appInstance, method, path, token, data);
}

module.exports = {
  TestApp,
  createTestApp,
  makeRequest,
  makeAuthenticatedRequest,
  makeAdminRequest
};