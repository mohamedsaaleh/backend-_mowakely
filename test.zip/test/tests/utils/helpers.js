const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const mongoose = require('mongoose');

const JWT_SECRET = process.env.JWT_SECRET || 'test-jwt-secret-key-for-testing';

class TestAuthHelper {
  static generateAccessToken(userId, role = 'client', options = {}) {
    return jwt.sign(
      {
        id: userId,
        type: 'access',
        role,
        ...options
      },
      JWT_SECRET,
      { expiresIn: '15m' }
    );
  }

  static generateRefreshToken(userId, role = 'client') {
    const token = require('crypto').randomBytes(64).toString('hex');
    return token;
  }

  static generateExpiredToken(userId) {
    return jwt.sign(
      { id: userId, type: 'access' },
      JWT_SECRET,
      { expiresIn: '-1s' }
    );
  }

  static generateInvalidToken() {
    return 'invalid.token.string';
  }

  static generateWrongTypeToken(userId) {
    return jwt.sign(
      { id: userId, type: 'refresh' },
      JWT_SECRET,
      { expiresIn: '15m' }
    );
  }

  static createAuthHeader(userId, role = 'client') {
    const token = this.generateAccessToken(userId, role);
    return `Bearer ${token}`;
  }

  static createRoleAuthHeader(userId, role) {
    return this.createAuthHeader(userId, role);
  }
}

class TestUserFixture {
  static createUserData(overrides = {}) {
    return {
      full_name: 'Test User',
      email: `test${Date.now()}@example.com`,
      password: 'Test@123456',
      role: 'client',
      phone: '+1-555-0000',
      ...overrides
    };
  }

  static createAdminData(overrides = {}) {
    return this.createUserData({
      full_name: 'Admin User',
      email: `admin${Date.now()}@example.com`,
      role: 'admin',
      ...overrides
    });
  }

  static createLawyerData(overrides = {}) {
    return this.createUserData({
      full_name: 'Lawyer User',
      email: `lawyer${Date.now()}@example.com`,
      role: 'lawyer',
      specialization: 'Family Law',
      years_of_experience: 5,
      office_address: '123 Main St',
      ...overrides
    });
  }

  static createClientData(overrides = {}) {
    return this.createUserData({
      full_name: 'Client User',
      email: `client${Date.now()}@example.com`,
      role: 'client',
      ...overrides
    });
  }

  static createUser(overrides = {}) {
    return this.createUserData(overrides);
  }

  static createAdmin(overrides = {}) {
    return this.createAdminData(overrides);
  }

  static createLawyer(overrides = {}) {
    return this.createLawyerData(overrides);
  }

  static createClient(overrides = {}) {
    return this.createClientData(overrides);
  }

  static createBannedUser() {
    return this.createUserData({
      email: `banned${Date.now()}@example.com`,
      is_banned: true
    });
  }

  static async hashPassword(password) {
    const salt = await bcrypt.genSalt(12);
    return bcrypt.hash(password, salt);
  }
}

class TestCaseFixture {
  static createCase(overrides = {}) {
    return {
      title: 'Test Case',
      description: 'Test case description',
      category: '507f1f77bcf86cd799439011',
      city: 'New York',
      budget: 5000,
      status: 'open',
      ...overrides
    };
  }

  static createOpenCase(overrides = {}) {
    return this.createCase({
      status: 'open',
      ...overrides
    });
  }

  static createInProgressCase(overrides = {}) {
    return this.createCase({
      status: 'in_progress',
      ...overrides
    });
  }

  static createCompletedCase(overrides = {}) {
    return this.createCase({
      status: 'completed',
      ...overrides
    });
  }
}

class TestOfferFixture {
  static createOffer(overrides = {}) {
    return {
      price: 4500,
      description: 'I can handle this case',
      estimated_duration: '30 days',
      status: 'pending',
      ...overrides
    };
  }

  static createPendingOffer(overrides = {}) {
    return this.createOffer({
      status: 'pending',
      ...overrides
    });
  }

  static createAcceptedOffer(overrides = {}) {
    return this.createOffer({
      status: 'accepted',
      ...overrides
    });
  }

  static createRejectedOffer(overrides = {}) {
    return this.createOffer({
      status: 'rejected',
      ...overrides
    });
  }
}

class TestCategoryFixture {
  static createCategory(overrides = {}) {
    return {
      name: 'FAMILY LAW',
      description: 'Family law cases',
      icon: 'family_restroom',
      is_active: true,
      ...overrides
    };
  }
}

class TestResponseHelper {
  static extractData(response) {
    return response.body;
  }

  static isSuccess(response) {
    return response.body.success === true;
  }

  static isError(response) {
    return response.body.success === false;
  }

  static getErrorMessage(response) {
    return response.body.message;
  }

  static getData(response) {
    return response.body.data;
  }
}

class TestValidationHelper {
  static invalidEmail() {
    return 'not-an-email';
  }

  static shortPassword() {
    return '123';
  }

  static weakPassword() {
    return 'password';
  }

  static longField() {
    return 'a'.repeat(300);
  }

  static emptyString() {
    return '';
  }

  static invalidRole() {
    return 'superuser';
  }

  static invalidCaseStatus() {
    return 'invalid_status';
  }
}

module.exports = {
  TestAuthHelper,
  TestUserFixture,
  TestCaseFixture,
  TestOfferFixture,
  TestCategoryFixture,
  TestResponseHelper,
  TestValidationHelper,
  DatabaseFixtures: require('./fixtures')
};