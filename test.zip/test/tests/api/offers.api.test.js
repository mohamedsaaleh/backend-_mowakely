const request = require('supertest');
const app = require('../../src/app');
const { TestAuthHelper, TestOfferFixture, DatabaseFixtures } = require('../utils/helpers');

describe('Offers API Tests', () => {
  let clientToken, clientUser, lawyerToken, lawyerUser;

  beforeEach(async () => {
    const client = await DatabaseFixtures.createClient();
    clientUser = client.user;
    clientToken = TestAuthHelper.generateAccessToken(clientUser._id, 'client');

    const lawyer = await DatabaseFixtures.createLawyer();
    lawyerUser = lawyer.user;
    lawyerToken = TestAuthHelper.generateAccessToken(lawyerUser._id, 'lawyer');
  });

  describe('POST /api/offers', () => {
    it('should create offer as lawyer', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });
      const offerData = TestOfferFixture.createPendingOffer();

      const response = await request(app)
        .post('/api/offers')
        .set('Authorization', `Bearer ${lawyerToken}`)
        .send({
          caseId: caseData.case._id,
          ...offerData
        });

      expect(response.status).toBe(201);
      expect(response.body.data.price).toBe(offerData.price);
      expect(response.body.data.status).toBe('pending');
    });

    it('should reject create as client', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });
      const offerData = TestOfferFixture.createPendingOffer();

      const response = await request(app)
        .post('/api/offers')
        .set('Authorization', `Bearer ${clientToken}`)
        .send({
          caseId: caseData.case._id,
          ...offerData
        });

      expect(response.status).toBe(403);
    });

    it('should reject create without auth', async () => {
      const caseData = await DatabaseFixtures.createCase();

      const response = await request(app)
        .post('/api/offers')
        .send({ caseId: caseData.case._id, price: 4500 });

      expect(response.status).toBe(401);
    });

    it('should reject create with invalid case ID', async () => {
      const response = await request(app)
        .post('/api/offers')
        .set('Authorization', `Bearer ${lawyerToken}`)
        .send({
          caseId: '507f1f77bcf86cd799439011',
          price: 4500
        });

      expect(response.status).toBe(404);
    });

    it('should reject create without price', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });

      const response = await request(app)
        .post('/api/offers')
        .set('Authorization', `Bearer ${lawyerToken}`)
        .send({ caseId: caseData.case._id });

      expect(response.status).toBe(400);
    });

    it('should reject negative price', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });

      const response = await request(app)
        .post('/api/offers')
        .set('Authorization', `Bearer ${lawyerToken}`)
        .send({ caseId: caseData.case._id, price: -100 });

      expect(response.status).toBe(400);
    });
  });

  describe('GET /api/offers/case/:caseId', () => {
    it('should get offers for a case', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });
      await DatabaseFixtures.createOffer({}, { user: lawyerUser }, caseData.case);

      const response = await request(app)
        .get(`/api/offers/case/${caseData.case._id}`)
        .set('Authorization', `Bearer ${clientToken}`);

      expect(response.status).toBe(200);
      expect(Array.isArray(response.body.data)).toBe(true);
    });

    it('should return empty array for case with no offers', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });

      const response = await request(app)
        .get(`/api/offers/case/${caseData.case._id}`)
        .set('Authorization', `Bearer ${clientToken}`);

      expect(response.status).toBe(200);
      expect(response.body.data).toEqual([]);
    });
  });

  describe('PUT /api/offers/:id', () => {
    it('should update own offer as lawyer', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });
      const offerData = await DatabaseFixtures.createOffer({}, { user: lawyerUser }, caseData.case);

      const response = await request(app)
        .put(`/api/offers/${offerData.offer._id}`)
        .set('Authorization', `Bearer ${lawyerToken}`)
        .send({ price: 4000, description: 'Updated description' });

      expect(response.status).toBe(200);
      expect(response.body.data.price).toBe(4000);
    });

    it('should reject update as non-owner', async () => {
      const otherLawyer = await DatabaseFixtures.createLawyer();
      const otherToken = TestAuthHelper.generateAccessToken(otherLawyer.user._id, 'lawyer');
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });
      const offerData = await DatabaseFixtures.createOffer({}, { user: lawyerUser }, caseData.case);

      const response = await request(app)
        .put(`/api/offers/${offerData.offer._id}`)
        .set('Authorization', `Bearer ${otherToken}`)
        .send({ price: 4000 });

      expect(response.status).toBe(403);
    });
  });

  describe('POST /api/offers/:id/accept', () => {
    it('should accept offer as case owner (client)', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });
      const offerData = await DatabaseFixtures.createOffer({}, { user: lawyerUser }, caseData.case);

      const response = await request(app)
        .post(`/api/offers/${offerData.offer._id}/accept`)
        .set('Authorization', `Bearer ${clientToken}`);

      expect(response.status).toBe(200);
      expect(response.body.data.status).toBe('accepted');
    });

    it('should reject accept as non-owner', async () => {
      const otherClient = await DatabaseFixtures.createClient();
      const otherToken = TestAuthHelper.generateAccessToken(otherClient.user._id, 'client');
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });
      const offerData = await DatabaseFixtures.createOffer({}, { user: lawyerUser }, caseData.case);

      const response = await request(app)
        .post(`/api/offers/${offerData.offer._id}/accept`)
        .set('Authorization', `Bearer ${otherToken}`);

      expect(response.status).toBe(403);
    });
  });

  describe('POST /api/offers/:id/reject', () => {
    it('should reject offer as case owner', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });
      const offerData = await DatabaseFixtures.createOffer({}, { user: lawyerUser }, caseData.case);

      const response = await request(app)
        .post(`/api/offers/${offerData.offer._id}/reject`)
        .set('Authorization', `Bearer ${clientToken}`);

      expect(response.status).toBe(200);
      expect(response.body.data.status).toBe('rejected');
    });
  });

  describe('DELETE /api/offers/:id', () => {
    it('should withdraw own offer', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });
      const offerData = await DatabaseFixtures.createOffer({}, { user: lawyerUser }, caseData.case);

      const response = await request(app)
        .delete(`/api/offers/${offerData.offer._id}`)
        .set('Authorization', `Bearer ${lawyerToken}`);

      expect(response.status).toBe(200);
    });

    it('should reject withdraw as non-owner', async () => {
      const otherLawyer = await DatabaseFixtures.createLawyer();
      const otherToken = TestAuthHelper.generateAccessToken(otherLawyer.user._id, 'lawyer');
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });
      const offerData = await DatabaseFixtures.createOffer({}, { user: lawyerUser }, caseData.case);

      const response = await request(app)
        .delete(`/api/offers/${offerData.offer._id}`)
        .set('Authorization', `Bearer ${otherToken}`);

      expect(response.status).toBe(403);
    });
  });
});