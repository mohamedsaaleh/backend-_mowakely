const request = require('supertest');
const app = require('../../src/app');
const { TestAuthHelper, TestCaseFixture, DatabaseFixtures } = require('../utils/helpers');

describe('Cases API Tests', () => {
  let clientToken, clientUser, lawyerToken, lawyerUser;

  beforeEach(async () => {
    const client = await DatabaseFixtures.createClient();
    clientUser = client.user;
    clientToken = TestAuthHelper.generateAccessToken(clientUser._id, 'client');

    const lawyer = await DatabaseFixtures.createLawyer();
    lawyerUser = lawyer.user;
    lawyerToken = TestAuthHelper.generateAccessToken(lawyerUser._id, 'lawyer');

    await DatabaseFixtures.createCategories();
  });

  describe('GET /api/cases (Public)', () => {
    it('should return paginated cases', async () => {
      const response = await request(app).get('/api/cases?page=1&limit=10');

      expect(response.status).toBe(200);
      expect(response.body.data).toHaveProperty('items');
      expect(response.body.data).toHaveProperty('pagination');
    });

    it('should filter by status parameter', async () => {
      const response = await request(app).get('/api/cases?status=open');

      expect(response.status).toBe(200);
    });

    it('should support search parameter', async () => {
      await DatabaseFixtures.createCase({ title: 'Legal Consultation' }, { user: clientUser });

      const response = await request(app).get('/api/cases?search=Consultation');

      expect(response.status).toBe(200);
    });
  });

  describe('POST /api/cases (Client)', () => {
    it('should create case with all required fields', async () => {
      const caseData = TestCaseFixture.createCase();

      const response = await request(app)
        .post('/api/cases')
        .set('Authorization', `Bearer ${clientToken}`)
        .send(caseData);

      expect(response.status).toBe(201);
      expect(response.body.data.title).toBe(caseData.title);
      expect(response.body.data.status).toBe('open');
      expect(response.body.data.client).toBe(clientUser._id.toString());
    });

    it('should set default priority', async () => {
      const caseData = TestCaseFixture.createCase({ priority: undefined });

      const response = await request(app)
        .post('/api/cases')
        .set('Authorization', `Bearer ${clientToken}`)
        .send(caseData);

      expect(response.status).toBe(201);
      expect(response.body.data.priority).toBe('medium');
    });

    it('should reject case for closed case', async () => {
      const caseData = TestCaseFixture.createCase();

      const createResponse = await request(app)
        .post('/api/cases')
        .set('Authorization', `Bearer ${clientToken}`)
        .send(caseData);

      await request(app)
        .put(`/api/cases/${createResponse.body.data._id}`)
        .set('Authorization', `Bearer ${clientToken}`)
        .send({ status: 'closed' });

      const response = await request(app)
        .post('/api/cases')
        .set('Authorization', `Bearer ${clientToken}`)
        .send(caseData);

      expect(response.status).toBe(400);
    });
  });

  describe('GET /api/cases/:id (Public)', () => {
    it('should return case by ID', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });

      const response = await request(app).get(`/api/cases/${caseData.case._id}`);

      expect(response.status).toBe(200);
      expect(response.body.data._id).toBe(caseData.case._id.toString());
    });

    it('should populate client field', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });

      const response = await request(app).get(`/api/cases/${caseData.case._id}`);

      expect(response.body.data.client).toHaveProperty('email');
    });

    it('should return 404 for invalid ID', async () => {
      const response = await request(app).get('/api/cases/invalid-id');

      expect(response.status).toBe(404);
    });
  });

  describe('PUT /api/cases/:id (Owner)', () => {
    it('should update own case title', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });

      const response = await request(app)
        .put(`/api/cases/${caseData.case._id}`)
        .set('Authorization', `Bearer ${clientToken}`)
        .send({ title: 'Updated Legal Case' });

      expect(response.status).toBe(200);
      expect(response.body.data.title).toBe('Updated Legal Case');
    });

    it('should update case status', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });

      const response = await request(app)
        .put(`/api/cases/${caseData.case._id}`)
        .set('Authorization', `Bearer ${clientToken}`)
        .send({ status: 'closed' });

      expect(response.status).toBe(200);
      expect(response.body.data.status).toBe('closed');
    });

    it('should reject update for other user case', async () => {
      const otherClient = await DatabaseFixtures.createClient();
      const otherToken = TestAuthHelper.generateAccessToken(otherClient.user._id, 'client');
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });

      const response = await request(app)
        .put(`/api/cases/${caseData.case._id}`)
        .set('Authorization', `Bearer ${otherToken}`)
        .send({ title: 'Hacked Title' });

      expect(response.status).toBe(403);
    });
  });

  describe('DELETE /api/cases/:id (Owner/Admin)', () => {
    it('should delete own case', async () => {
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });

      const response = await request(app)
        .delete(`/api/cases/${caseData.case._id}`)
        .set('Authorization', `Bearer ${clientToken}`);

      expect(response.status).toBe(200);

      const getResponse = await request(app).get(`/api/cases/${caseData.case._id}`);
      expect(getResponse.status).toBe(404);
    });

    it('should allow admin to delete any case', async () => {
      const admin = await DatabaseFixtures.createAdmin();
      const adminToken = TestAuthHelper.generateAccessToken(admin._id, 'admin');
      const caseData = await DatabaseFixtures.createCase({}, { user: clientUser });

      const response = await request(app)
        .delete(`/api/cases/${caseData.case._id}`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
    });
  });

  describe('GET /api/cases/client/my-cases', () => {
    it('should get client own cases', async () => {
      await DatabaseFixtures.createCase({}, { user: clientUser });

      const response = await request(app)
        .get('/api/cases/client/my-cases')
        .set('Authorization', `Bearer ${clientToken}`);

      expect(response.status).toBe(200);
      expect(response.body.data.items.length).toBeGreaterThan(0);
    });
  });

  describe('GET /api/cases/lawyer/assigned', () => {
    it('should get lawyer assigned cases', async () => {
      await DatabaseFixtures.createCase({ lawyer: lawyerUser._id }, { user: clientUser });

      const response = await request(app)
        .get('/api/cases/lawyer/assigned')
        .set('Authorization', `Bearer ${lawyerToken}`);

      expect(response.status).toBe(200);
    });
  });
});