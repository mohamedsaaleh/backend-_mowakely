const Joi = require('joi');
const { AppError } = require('../middlewares/error.middleware');

const objectId = Joi.string().pattern(/^[0-9a-fA-F]{24}$/).messages({
  'string.pattern.base': 'Invalid ID format'
});

const pagination = Joi.object({
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(10),
  sort: Joi.string().default('-createdAt'),
  order: Joi.string().valid('asc', 'desc').default('desc')
});

const objectIdValidation = (value, helpers) => {
  if (!value.match(/^[0-9a-fA-F]{24}$)) {
    return helpers.error('any.invalid');
  }
  return value;
};

const objectIdSchema = Joi.object({
  id: Joi.string().custom(objectIdValidation, 'Object ID validation').required()
});

const queryPagination = Joi.object({
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(10),
  sort: Joi.string().default('-createdAt'),
  order: Joi.string().valid('asc', 'desc').default('desc'),
  search: Joi.string().allow(''),
  fields: Joi.string()
});

const idParam = (paramName = 'id') => {
  return Joi.object({
    [paramName]: Joi.string().custom(objectIdValidation, 'Object ID validation').required()
  });
};

const validateObjectId = (id) => {
  if (!id.match(/^[0-9a-fA-F]{24}$)) {
    throw new AppError('Invalid ID format', 400);
  }
};

const parseSort = (sortStr) => {
  if (!sortStr) return { createdAt: -1 };

  const sortObj = {};
  const fields = sortStr.split(',');

  fields.forEach(field => {
    const isDescending = field.startsWith('-');
    const key = isDescending ? field.slice(1) : field;
    sortObj[key] = isDescending ? -1 : 1;
  });

  return sortObj;
};

const getPagination = (page = 1, limit = 10) => {
  const pageNum = parseInt(page) || 1;
  const limitNum = parseInt(limit) || 10;

  return {
    skip: (pageNum - 1) * limitNum,
    limit: Math.min(limitNum, 100),
    page: pageNum,
    limitNum
  };
};

const buildFilter = (query, allowedFields = []) => {
  const filter = {};

  allowedFields.forEach(field => {
    if (query[field] !== undefined) {
      filter[field] = query[field];
    }
  });

  if (query.search) {
    filter.$or = [
      { title: { $regex: query.search, $options: 'i' } },
      { description: { $regex: query.search, $options: 'i' } }
    ];
  }

  return filter;
};

module.exports = {
  objectId,
  pagination,
  objectIdSchema,
  queryPagination,
  idParam,
  validateObjectId,
  parseSort,
  getPagination,
  buildFilter
};